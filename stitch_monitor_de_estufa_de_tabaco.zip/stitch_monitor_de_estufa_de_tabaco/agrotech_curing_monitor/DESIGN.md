---
name: AgroTech Curing Monitor
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#40493d'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#707a6c'
  outline-variant: '#bfcaba'
  surface-tint: '#1b6d24'
  primary: '#0d631b'
  on-primary: '#ffffff'
  primary-container: '#2e7d32'
  on-primary-container: '#cbffc2'
  inverse-primary: '#88d982'
  secondary: '#50652a'
  on-secondary: '#ffffff'
  secondary-container: '#cfe99f'
  on-secondary-container: '#546a2e'
  tertiary: '#774c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#986200'
  on-tertiary-container: '#ffeede'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a3f69c'
  primary-fixed-dim: '#88d982'
  on-primary-fixed: '#002204'
  on-primary-fixed-variant: '#005312'
  secondary-fixed: '#d2eca2'
  secondary-fixed-dim: '#b6d088'
  on-secondary-fixed: '#131f00'
  on-secondary-fixed-variant: '#394d14'
  tertiary-fixed: '#ffddb5'
  tertiary-fixed-dim: '#ffb957'
  on-tertiary-fixed: '#2a1800'
  on-tertiary-fixed-variant: '#643f00'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e3e2e2'
typography:
  display-kpi:
    fontFamily: Roboto Flex
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-kpi-sm:
    fontFamily: Roboto Flex
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Roboto Flex
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Roboto Flex
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Roboto Flex
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-lg:
    fontFamily: Roboto Flex
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 26px
  title-md:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
  title-sm:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-lg:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.1px
  label-md:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.5px
  label-sm:
    fontFamily: Roboto Flex
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.5px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system establishes a high-reliability, native Android Material 3 interface engineered specifically for agricultural IoT telemetry and tobacco curing operations. The target audience includes agricultural engineers, kiln technicians, and farm operators working under intense direct sunlight, high humidity, and time-critical operational windows.

The design movement combines **Material 3 Utility** with **Industrial AgroTech Ergonomics**:
- **Utilitarian Clarity**: High legibility, zero decorative ambiguity, and immediate glanceability for critical metrics (temperature, wet-bulb differential, relative humidity, airflow stages).
- **Physical Groundedness**: Color cues map directly to real-world biological states—foliar maturation, moisture loss, yellowing, leaf-drying, and stem-drying phases.
- **Fail-Safe Visual Hierarchy**: Harsh ambient lighting in field conditions necessitates strict contrast boundaries, generous tactile target zones (minimum 48x48dp), and rapid recognition of telemetry states (Normal, Warning, Critical, Offline).

## Colors

The palette is tuned for high-contrast outdoors, industrial telemetry readability, and Material 3 role compliance:

- **Primary (`#2E7D32` & `#1B5E20`)**: Represents operational stability, ideal leaf curing states, and active hardware connectivity.
- **Secondary (`#4E6649` / Sage)**: Subdued organic tone used for auxiliary hardware channels, secondary filter chips, and non-critical status indicators.
- **Tertiary & Amber Attention (`#F9A825` / `#FFF9C4`)**: Critical for curing stage monitoring (e.g., yellowing transition phases) and soft warnings such as sensor threshold drifts.
- **Surface & Containers (`#F4F7F4`, `#FFFFFF`, `#E8EFE8`)**: Tinted neutral greens prevent stark white glare during prolonged tablet/handheld field use while maintaining maximum contrast against dark UI glyphs.
- **Alert & Critical (`#D32F2F` / `#FFEBEE`)**: Thermal runaways, flame failures, and extreme probe variances.
- **Disconnected & Offline (`#757575` / `#EEEEEE`)**: Clear desaturation to delineate missing telemetry feeds or offline LoRaWAN/Wi-Fi gateways without false panic.

## Typography

The type system relies on `Roboto Flex` to balance systematic Android Material 3 parity with dense, highly legible metric reporting:

- **Tabular Figures & Metrics**: Numeric readouts for temperature (`°F`), wet-bulb differentials, humidity (`%`), and barn chamber hours leverage proportional, bold figures (`display-kpi` and `display-kpi-sm`) to avoid horizontal jitter during real-time streaming over MQTT or BLE.
- **Hierarchy for Fast Scanning**: Titles clearly distinguish barn cluster IDs (e.g., `Estufa #04 - Cura Folha`) from ambient sensor values.
- **Labels & Micro-data**: `label-md` and `label-sm` use bolded weights and deliberate tracking for hardware badges, probe statuses, and timestamp flags.

## Layout & Spacing

A strictly disciplined 4dp/8dp incremental grid guarantees rhythm and finger-friendly targets for handheld industrial use:

- **Mobile Phone (Default Compact)**: 4-column layout with 16dp outer screen margin (`margin`) and 16dp gutter (`gutter`). Touch targets remain at or above 48dp x 48dp.
- **Tablet / In-barn Wall Terminals (Medium & Expanded)**: Scales to an 8- or 12-column layout with 24dp margins (`margin-tablet`), enabling side-by-side comparative views of multiple curing chambers.
- **Internal Component Spacing**:
  - `space-xs` (4dp): Used for badge dot-to-text gaps and inline metric unit offsets.
  - `space-sm` (8dp): Card header internal spacing, list-item icon spacing.
  - `space-md` (16dp): Default component internal padding, card padding, and vertical rhythm between metric blocks.
  - `space-lg` (24dp): Separation between major dashboard sections (e.g., Curing Curve Stage vs. Chamber Sensor Matrix).

## Elevation & Depth

Visual hierarchy leverages Material 3 tonal color elevation combined with soft, non-intrusive ambient shadows:

- **Level 0 (Flat / Canvas)**: `md-sys-color-background` (`#F4F7F4`) provides the foundation.
- **Level 1 (Card & Containers)**: `md-sys-color-surface` (`#FFFFFF`) with a 1dp subtle border (`#E8EFE8`) and zero to minimal ambient shadow (`0px 1px 3px rgba(0, 34, 4, 0.06)`).
- **Level 2 (Active Interactive Cards & Top App Bar on Scroll)**: Light elevation lift with `0px 3px 6px rgba(0, 34, 4, 0.08)` and surface tinting using `md-sys-color-surface-variant`.
- **Level 3 (Modal Bottom Sheets, Dialogs & Floating Actions)**: Shadow `0px 6px 12px rgba(0, 34, 4, 0.12)` with full backdrop scrim (`rgba(25, 29, 25, 0.4)`).
- **Critical Alert Elevation**: Alert banners utilize tonal containment (`md-sys-color-error-container`) with no drop shadow, prioritizing chromatic urgency over artificial 3D depth.

## Shapes

The design uses roundedness tier `2` (0.5rem base radius) calibrated to native Material 3 norms:

- **Base Components (`rounded-md`, 8dp / 0.5rem)**: Text inputs, snackbars, and segmented control buttons.
- **Cards & Data Modules (`rounded-2xl`, 16dp / 1rem)**: Telemetry cards, KPI blocks, and alert containers.
- **Floating Action Buttons & Badges (`rounded-full`)**: Pulse status badges, pill navigation markers, and quick-action icon containers.
- **Bottom Navigation Surface**: Flat base with 0dp radius on lower bounds and smooth transitions for pill selectors.

## Components

### 1. Cards (Estufa Telemetry & Sensor Blocks)
- **Container**: White surface (`#FFFFFF`) framed with a 1dp border (`#C1C9BF` at 50% opacity or `#E8EFE8`), corner radius `rounded-2xl` (16dp), 16dp internal padding.
- **Header**: Chamber identifier (`Estufa 01`), curing phase pill badge (e.g., `Amarelecimento`, `Murcha`, `Secagem Folha`, `Secagem Talo`), and real-time connectivity status dot.
- **Data Body**: Two-column split for Primary KPIs:
  - Left: Temperature (°F) in `display-kpi` with target setpoint indicator below.
  - Right: Relative Humidity (%) in `display-kpi` with wet-bulb probe status.
- **Footer**: Sparkline / mini-graph trendline and timestamp (`Atualizado há 12s`).

### 2. Status Badges & Hardware Indicators
- **Online Badge**: Pill container with `md-sys-color-primary-container` (`#A5D6A7`), text in `md-sys-color-on-primary-container`, featuring an 8dp solid circular dot with a continuous concentric CSS/native pulse animation.
- **Offline / Desconectado Badge**: Neutral grey container (`#EEEEEE`), label `Desconectado`, 8dp static dot (`#757575`). Telemetry values inside the card dim to `md-sys-color-offline` with a dashed line replacement (`-- °F`).
- **Attention Badge**: `#FFF9C4` container with `#261900` text for damper motor warnings or mild heat fluctuations.
- **Critical Alert Badge**: `#FFEBEE` container with `#D32F2F` text and warning triangle icon for burner lockouts or high-limit trips.

### 3. Top App Bar (Material 3 Small/Center-Aligned)
- **Background**: `#FFFFFF` when pinned, shifting to `#E8EFE8` with slight elevation upon vertical scroll.
- **Title**: Facility name or active barn zone (`Complexo Norte - Estufas`).
- **Actions**: Emergency stop/ventilation override shortcut, connection health indicator, and overflow filter action.

### 4. Bottom Navigation Bar (Material 3 Navigation Bar)
- **Structure**: 4 fixed destinations:
  1. *Início* (Dashboard overview of all curing units)
  2. *Histórico* (Curing curves, thermal logs, past harvest batches)
  3. *Alertas* (Active warnings, probe fault log, push notification queue)
  4. *Perfil* (Technician config, LoRaWAN setup, threshold calibrations)
- **State Styling**: Active item features an elongated pill indicator in `#A5D6A7` with `#002204` icon/text fill. Inactive items display in `#414941`. Height is fixed to standard M3 80dp.

### 5. Buttons & Controls
- **Primary Action (Filled)**: Background `#2E7D32`, text `#FFFFFF`, 48dp minimum touch height, `rounded-full` or `rounded-lg` (8dp).
- **Secondary (Tonal / Outlined)**: Background `#E8EFE8` or bordered with 1dp `#717971`.
- **Segmented Buttons**: Used for switching metric views (`°F` vs `°C`) and chart resolutions (`1h`, `6h`, `24h`, `Lote Completo`).

### 6. Input Fields & Calibration Controls
- **Text Inputs & Setpoint Steppers**: Outlined M3 style with 1dp `#717971` boundary, dynamic green focus ring (`#2E7D32`, 2dp), floating labels, and integrated step buttons for coarse/fine temperature adjustments (+/- 1°F).